var filmes = {
    nome: "The Imitation Game",
    visto: true,
    nota: 5
}
console.log(filmes)

filmes.nome = "Hackers"
filmes.visto =false;
filmes.nota = 4
console.log(filmes)

filmes.nome = "The Social Network"
filmes.visto = false;
filmes.nota = 3
console.log(filmes)

filmes.nome = "Pirates of the Silicon Valley"
filmes.visto = true
filmes.nota = 5
console.log(filmes)

filmes.nome = "Revolution OS"
filmes.visto = true;
filmes.nota = 5
console.log(filmes)