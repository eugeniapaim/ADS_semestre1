document.addEventListener('DOMContentLoaded', function () {
    const nomeInput = document.getElementById('nome');
    const emailInput = document.getElementById('email');
    const ajudaNome = document.getElementById('ajuda_nome');
    const ajudaEmail = document.getElementById('ajuda_email');
    const quantCamMascInput = document.getElementById('quantCamMasc');
    const quantCamFemInput = document.getElementById('quantCamFem');
    const totalInput = document.getElementById('total');
    const btMaisMasc = document.getElementById('bt+Masc');
    const btMenosMasc = document.getElementById('bt-Masc');
    const btMaisFem = document.getElementById('bt+Fem');
    const btMenosFem = document.getElementById('bt-Fem');
    const concluirButton = document.getElementById('concluir');

    const precoCamisaMasc = 25.00; 
    const precoCamisaFem = 20.00; 

    
    function validarNome() {
        if (nomeInput.value.length < 2) {
            ajudaNome.textContent = "Nome inválido!"
        } else {
            ajudaNome.textContent = ""
        }
    }

    
    function validarEmail() {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(emailInput.value)) {
            ajudaEmail.textContent = "E-mail inválido";
        } else {
            ajudaEmail.textContent = "";
        }
    }

    
    function atualizarTotal() {
        const quantCamMasc = parseInt(quantCamMascInput.value);
        const quantCamFem = parseInt(quantCamFemInput.value);
        const total = (quantCamMasc * precoCamisaMasc) + (quantCamFem * precoCamisaFem);
        totalInput.value = `R$ ${total.toFixed(2)}`;
    }

    
    function alterarQuantidade(input, incremento) {
        let quantidade = parseInt(input.value);
        quantidade += incremento;
        if (quantidade < 0) quantidade = 0;
        input.value = quantidade;
        atualizarTotal();
    }

    
    nomeInput.addEventListener('input', validarNome);
    emailInput.addEventListener('input', validarEmail);

    
    btMaisMasc.addEventListener('click', function () {
        alterarQuantidade(quantCamMascInput, 1);
    });
    btMenosMasc.addEventListener('click', function () {
        alterarQuantidade(quantCamMascInput, -1);
    });
    btMaisFem.addEventListener('click', function () {
        alterarQuantidade(quantCamFemInput, 1);
    });
    btMenosFem.addEventListener('click', function () {
        alterarQuantidade(quantCamFemInput, -1);
    });

    
    concluirButton.addEventListener('click', function () {
        alert('Compra concluída! Total: ' + totalInput.value);
    });
});